import boto3
import csv
import argparse
import sys,os,json
import  botocore
import subprocess
import time, logging
from os import listdir
from os.path import isfile, join
from jinja2 import Template
from botocore.exceptions import ClientError
from datetime import datetime
from pytz import timezone

mypath="./"
csvDataList=[]
error =[]

SSMAgentDocument=""
header1 = ["Account-id","Region","Instance-id","Tripwire"]
header2 = ["Account-id","Region","Instance-id","PrivateIP","PrivateDNS","PublicIP","PublicDNS","OperatingSystem","Status","AlertFrequency","EmailIDs"]
outputFileName = 'TripwireInstallationLogs'+datetime.now(timezone('UTC')).strftime("%d%m%Y%I%M%S")+'.csv' 
VMDetailsFile = 'AgentInstalledVMdetailsFile'+datetime.now(timezone('UTC')).strftime("%d%m%Y%I%M%S")+'.csv'
parameters_file = 'installtripwire.parameters.json'

def assume_role(role_arn, session_name,credentials = None):
    if credentials == None:
        sts_client = boto3.client('sts')
    else:
        sts_client = boto3.client('sts',
            aws_access_key_id = credentials['AccessKeyId'],
            aws_secret_access_key = credentials['SecretAccessKey'],
            aws_session_token = credentials['SessionToken']
        )

    #print (sts_client.get_caller_identity())

    assumedRoleObject = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName=session_name,
        DurationSeconds=990
    )
    return assumedRoleObject

#def dummy_method(name):
#    return name

def GetAccountCredentials(AccountId, MasterRoleCredentials):
    try:
        role = GetFedRolesOperationsRole(AccountId,MasterRoleCredentials) # Added for Jump Account Integration
        accountRoleArn = "arn:aws:iam::" + AccountId + ":role/"+role # Modified for Jump Account Integration
        accountRole = assume_role(accountRoleArn, AccountId, MasterRoleCredentials)
        accountCredentials = accountRole['Credentials']
    except: return "InvalidCredentials"
    return accountCredentials
    
def GetFedRolesOperationsRole(AccountId,Credentials):
    try:
        print ("Calling DB ")
        keyval = AccountId+"-WKFedRoles-Operations"
        print (keyval)
        dynamodb = boto3.resource('dynamodb',
            region_name='us-east-1',
            aws_access_key_id     = Credentials['AccessKeyId'],
            aws_secret_access_key = Credentials['SecretAccessKey'],
            aws_session_token     = Credentials['SessionToken'],
            )
    
        table = dynamodb.Table('WK-FedRoles')
    
        response = table.get_item(
        
            Key={
                'AccountFedRole':  keyval,
            },
            AttributesToGet=['RoleName']
            )
    #print response
        print ('WKFedRoles-Operations for ' ,AccountId , 'is ' , response['Item']['RoleName'])
        role = response['Item']['RoleName']
    except: return "InvalidCredential"
    return role
def NewStsFunc( AccountId,RoleName ):
        try:
            arn='arn:aws:iam::'+str(AccountId)+':role/'+RoleName
            session_name='NewSession-'+str(AccountId)
            client = boto3.client('sts',regionName='us-east-2')
            response = client.assume_role(
            RoleArn=arn,
            RoleSessionName=sessionName,
            )
        except: return "wrongdatapassed"
        return response['Credentials']

def StsFunc1( AccountId,RoleName,AccessKey,SecretKey,Token ):
        try:
            arn='arn:aws:iam::'+str(AccountId)+':role/'+RoleName
            sessionName='NewSession-'+str(AccountId)
            client = boto3.client('sts',region_name='us-east-2',aws_access_key_id=AccessKey,aws_secret_access_key=SecretKey,aws_session_token=Token)
            response = client.assume_role(
            RoleArn=arn,
            RoleSessionName=sessionName,
           )
        except: return "wrongdata"
        return response['Credentials']

########################################################
#1. Checking SSM document 
########################################################

def checkSSMDocument(DocName, Region, Credentials):
  try:
      if Credentials == None:
          ssm_client = boto3.client('ssm')
      else:
           ssm_client = boto3.client('ssm',region_name=Region,
                     aws_access_key_id     = Credentials['AccessKeyId'],
                     aws_secret_access_key = Credentials['SecretAccessKey'],
                     aws_session_token     = Credentials['SessionToken'],)
    

      response = ssm_client.describe_document(Name=DocName)
  except botocore.exceptions.ClientError as e:
    print  (e.response['Error']['Message'])
    return 'Validationfailed'
  return response

'''
#######################################################################
#1. Download SSM document (if uploaded on S3)
#######################################################################
def downloadDocument(bucketName, fileName, localPath, master_role_credentials):
  print ("file to be downloaded: ", fileName)

  role = get_fedRoles_operations_role('account_id',master_role_credentials)
  account_cred = sts_func1('SSMDocumentAccount',role,
                 master_role_credentials['AccessKeyId'],
                 master_role_credentials['SecretAccessKey'],
                 master_role_credentials['SessionToken'],)

  s3 = boto3.resource('s3', 
                 aws_access_key_id     = account_cred['AccessKeyId'],
                 aws_secret_access_key = account_cred['SecretAccessKey'],
                 aws_session_token     = account_cred['SessionToken'],)
    
  try:
      s3.Bucket(bucketName).download_file(fileName, localPath)
      print ("success")

  except botocore.exceptions.ClientError as e:
      print (e)
      if e.response['Error']['Code'] == "404":
          print("The object does not exist.")
      else:
          raise
'''
#######################################################################
#1. Create SSM document through API
#######################################################################
def createDocument(localPath, region, docName, credentials):
  content = ''
  print ("Creating Document..",docName)
  print(localPath)
  try:
      with open(localPath) as ssmDocumentFile:
            content = ssmDocumentFile.read()
            print (content)
            if credentials == None:
                ssm = boto3.client('ssm')
            else:
                ssm = boto3.client('ssm', region_name=region,
                          aws_access_key_id     = credentials['AccessKeyId'],
                          aws_secret_access_key = credentials['SecretAccessKey'],
                          aws_session_token     = credentials['SessionToken'],)

            response = ssm.create_document(Name = docName, Content = content, DocumentType = "Command")
            ssmDocumentFile.close()
            return response             
  except Exception as e:
        print (e)
  #return response
#######################################################################
#1. Delete SSM document through API
#######################################################################

def DeleteDocument(DocName, Region, Credentials):
    if Credentials == None:
         ssm_client = boto3.client('ssm')
    else:
        ssm_client = boto3.client('ssm', region_name=Region,
                          aws_access_key_id     = Credentials['AccessKeyId'],
                          aws_secret_access_key = Credentials['SecretAccessKey'],
                          aws_session_token     = Credentials['SessionToken'])
    try:
        ssm_client.modify_document_permission(Name=DocName, PermissionType='Share', AccountIdsToRemove=["All"])
        response = ssm_client.delete_document(Name=DocName)
        print ("document deleted: ", DocName)
        return response
    except  Exception as e:
        print (e)

#######################################################################
#1. createOutputBucket
#######################################################################

def CreateOutputBucket(AccountId, MasterRoleCredentials):
  
  SSMOutputAccount = AccountId
  bucketName=str(AccountId)+'outputS3BucketName'
  print ("Output bucket to be created: ", bucketName)
  account_Id = str(AccountId)
  role = GetFedRolesOperationsRole(AccountId,MasterRoleCredentials)
  if MasterRoleCredentials == None:
     # sts_client = boto3.client('sts')
      s3_client = boto3.client("s3")
  else:
      account_cred = StsFunc1( SSMOutputAccount,role,
                     MasterRoleCredentials['AccessKeyId'],
                     MasterRoleCredentials['SecretAccessKey'],
                     MasterRoleCredentials['SessionToken'])


      s3 = boto3.resource('s3',
                          aws_access_key_id     = account_cred['AccessKeyId'],
                          aws_secret_access_key = account_cred['SecretAccessKey'],
                          aws_session_token     = account_cred['SessionToken'],)
  try:
    if (s3.Bucket(bucketName) in s3.buckets.all()) == False:
      response=s3_client.create_bucket(ACL='public-read-write', Bucket=bucketName)
      print ("Bucket Created: ",response)
    else:
      print ("The bucket: ",bucketName," already exists...")
  except Exception as e:
    print (e)
  return bucketName

###########################################################
# Upload tag and output files to S3 bucket
###########################################################
def UploadFileToBucket(FileName, Credentials, Bucket, ObjectName=None):
    
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """

    # If S3 ObjectName was not specified, use file_name
    if ObjectName is None:
        ObjectName = FileName

    # Upload the file
    if Credentials == None:
        s3_client = boto3.client('s3')
    else:
        s3_client = boto3.client('s3',
                          aws_access_key_id=Credentials['AccessKeyId'],
                          aws_secret_access_key=Credentials['SecretAccessKey'],
				    	  aws_session_token= Credentials['SessionToken'])
    try:
        response = s3_client.upload_file(FileName, Bucket, ObjectName,
                                         ExtraArgs={'ACL': 'public-read'})
        return response
        #print ('File '+file_name+' has been uploaded to S3 Bucket '+Bucket)
    except: return 'error'

######################################################################################
#1. Check if SSM document already there
######################################################################################
def CreateSSMDocuments(SSMAgentDocument,JsonDocument,Region, Credentials, MasterRoleCredentials, CurrentAccount):
  print ("Test")
  print (SSMAgentDocument)
  status = checkSSMDocument(SSMAgentDocument, Region, Credentials)
  if status == '':
    print ("Inside if")
    
    LocalPath=JsonDocument
    createDocument(LocalPath, Region, SSMAgentDocument, Credentials)
  else:
    print ("Inside else")
    
    LocalPath=JsonDocument
    DeleteDocument(SSMAgentDocument, Region, Credentials)
    createDocument(LocalPath, Region, SSMAgentDocument, Credentials,)
  print ("creating output bucket...")
  bucketName = CreateOutputBucket(CurrentAccount,MasterRoleCredentials)
  return bucketName

##################################################################################
#1. Getting VM Details file name as output Variable
##################################################################################

def GetFileNameAsOutputVariable(VMDetailsFile,OutputFileName ) :
    print (VMDetailsFile)
    try:
        
        command_output1 = '"##vso[task.setvariable variable=VMDetailsFileName;]"+VMDetailsFile'
        print("command_output1:",command_output1)
        #return 'output1'                
        
        rc = subprocess.call(command_output1,shell=True)
        print (OutputFileName)
        command_output2 = '"##vso[task.setvariable variable=LogFileName;]"+OutputFileName'
        print("command_output1:",command_output2)
        #return 'output2'                
        rc = subprocess.call(command_output2,shell=True)
        print(os.path.abspath(VMDetailsFile))
        onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
        print(onlyfiles)
        return 'success'
    except: return 'Failure'


# Installing Tripwire agent on VMs
def InstallTripwire(AccountList, RegionList,InstanceIds,MasterCredentials):
    for acc in AccountList:
        accid = int(acc)
        csvDataList.append(accid)
        print ("Gathering data for account id: ",acc)
        print ("account_info",acc)
        try:
            account_cred = GetAccountCredentials(acc, MasterCredentials)
            temp_access1 = account_cred['AccessKeyId'],
            temp_secret1 = account_cred['SecretAccessKey'],
            temp_token1 = account_cred['SessionToken']
            
            print ("account_info")
            for region in RegionList:
                csvDataList.append(region)
                
                ssm_client = boto3.client('ssm',region_name=region,
                            aws_access_key_id     = account_cred['AccessKeyId'],
                            aws_secret_access_key = account_cred['SecretAccessKey'],
                            aws_session_token     = account_cred['SessionToken'],)
                print ("ssm")
                SSMIdUnix = []
                SSMIdWin = []
                AllSSMId = []
                SSMIdVM = []

                try:
                    response = ssm_client.describe_instance_information()
                except botocore.exceptions.NoRegionError as e:
                    print(e)
                # there may be more.use token
                getVMDetails (response ,SSMIdUnix , SSMIdWin ,AllSSMId,InstanceIds)
                while "NextToken" in response.keys():
                    response = ssm_client.describe_instance_information(NextToken=response['NextToken'])
                    print (response)
                    getVMDetails (response ,SSMIdUnix , SSMIdWin ,AllSSMId, InstanceIds)

                s3Client= boto3.client('s3',
                            aws_access_key_id     = account_cred['AccessKeyId'],
                            aws_secret_access_key = account_cred['SecretAccessKey'],
                            aws_session_token     = account_cred['SessionToken'],)

                print ("For region:",region)
                print ("Instances with SSM:",AllSSMId)
                print ("Windows Instances with SSM:",SSMIdWin)
                print ("Linux Instances with SSM:",SSMIdUnix)
                print ("Checking agent version ")

                CheckAgentVersion(axonAgentBucket, axonAgentVersion, account_cred)
                CreateSSMFileFromTemplate(accid)
            
                while SSMIdUnix != []:
                    SSMAgentDocument="TripwireLinuxInstall"
                    JsonDocument= 'TripwireLinuxInstall.json'
                    outputFolderName='/awsrunShellScript/CheckAndInstallTripWireOnLinux/stdout'
                    bucketName = CreateSSMDocuments(SSMAgentDocument,JsonDocument,Region, AccountCred, MasterCredentials, accid)
                    print ("bucketName")
                    print (bucketName)
                    CreateTagFile(buisness_unit, cloud_environment, program_initiative, acc)
                    uploadFileToBucket('metadata.yml', account_cred, bucketName)
                    processVMs(SSMIdUnix,AllSSMId,SSMAgentDocument,outputFolderName,bucketName,ssm_client,s3Client,accid, region,MasterCredentials)
                    uploadFileToBucket(VMDetailsFile, account_cred, bucketName)
                    uploadFileToBucket(outputFileName, account_cred, bucketName)
                    break
                while SSMIdWin != []:
                    SSMAgentDocument="TripwireWinInstall"
                    JsonDocument='TripwireWindowsInstall.json'
                    outputFolderName='/awsrunPowerShellScript/PatchWindows/stdout'
                    bucketName = createSSMDocuments(SSMAgentDocument,JsonDocument,Region, AccountCred, MasterCredentials, accid)
                    print ("bucketName")
                    print (bucketName)
                    CreateTagFile(buisness_unit, cloud_environment, program_initiative, acc)
                    uploadFileToBucket('metadata.yml', account_cred, bucketName)
                    processVMs(SSMIdWin,AllSSMId,SSMAgentDocument,outputFolderName,bucketName,ssm_client,s3Client,accid, region,MasterCredentials)
                    uploadFileToBucket(VMDetailsFile, account_cred, bucketName)
                    uploadFileToBucket(outputFileName, account_cred, bucketName)
                    break
                while SSMIdUnix == [] and SSMIdWin ==[ ] :
                    data = [accid, region, '-', 'No UnixVM or windows with SSM enabled found']
                    with open(outputFileName, 'a') as f:
                            writer = csv.writer(f)
                            writer.writerow(data)
                            f.close()

        except Exception as e:
            print ("error ",e,"on",accid)
            with open(r'unreachable.csv', 'a') as f:
                    writer = csv.writer(f)
                    writer.writerow((accid,e))
                    f.close()

    GetFileNameAsOutputVariable(VMDetailsFile,outputFileName)

# Getting VM details like OS type, IPs, etc.
def getVMDetails (response ,SSMIdUnix , SSMIdWin ,AllSSMId, InstanceIds) :
    try:
        i = 0
        for InstanceList in response["InstanceInformationList"]:
        
            i = i+1 
       
            InstanceId = InstanceList["InstanceId"]
            InstanceIp = InstanceList["IPAddress"]
            InstancePlatform = InstanceList["PlatformType"]
            # Adding all SSM enabled VMs
            InstanceDetail = {} 
            InstanceDetail[InstanceId ] = InstancePlatform
            InstanceDetail['IP' ] = InstanceIp
            AllSSMId.append(InstanceDetail)

            if InstancePlatform == 'Linux':
                if(len(InstanceIds) == 0):
                    SSMIdUnix.append(InstanceId)
                
                else :
                    if(InstanceId in InstanceIds): # Add only those ids which are part of Instance id
                        SSMIdUnix.append(InstanceId)
                     
            else:
                if(len(InstanceIds) == 0):   
                    SSMIdWin.append(InstanceId)
                else:
                    if(InstanceId in InstanceIds):
                        SSMIdWin.append(InstanceId)
                
    except:return 'win'
# Execution SSM commands on VMs
def processVMs(SSMIdVM,AllSSMId,SSMAgentDocument,outputFolderName,bucketName,ssm_client,s3Client,accid, region,MasterCredentials) :
    try:
        print ("SendCommand in one go for all instances")
        print (SSMIdVM)
        response_VM = ssm_client.send_command( InstanceIds=SSMIdVM, DocumentName=SSMAgentDocument, OutputS3BucketName=bucketName )
        print ("response: ",response_VM)
        cmndid = str(response_VM["Command"]["CommandId"])
        print ("cmd:",cmndid)
        acc = str(accid)
        try:
            account_cred = get_account_credentials(acc, MasterCredentials)
            temp_access1 = account_cred['AccessKeyId'],
            temp_secret1 = account_cred['SecretAccessKey'],
            temp_token1 = account_cred['SessionToken']
        
            ec2client = boto3.client('ec2',region_name=region,
                            aws_access_key_id     = account_cred['AccessKeyId'],
                            aws_secret_access_key = account_cred['SecretAccessKey'],
                            aws_session_token     = account_cred['SessionToken'],)
        
            for instid in SSMIdVM:
                a = str(instid)
                response = ec2client.describe_instances(InstanceIds=[instid])
                print("Describing Instances")
                print(response)
                try:
                    PrivateIP = response['Reservations'][0]['Instances'][0]['PrivateIpAddress']
                except KeyError as error:
                    PrivateIP = " "
                try:
                    PrivateDNS = response['Reservations'][0]['Instances'][0]['PrivateDnsName']
                except KeyError as error:
                    PrivateDNS = " "   
                try:
                    PublicIP = response['Reservations'][0]['Instances'][0]['PublicIpAddress']
                except KeyError as error:
                    PublicIP = " "
                try:
                    PublicDNS = response['Reservations'][0]['Instances'][0]['PublicDnsName']
                except KeyError as error:
                    PublicDNS = " "
                try:
                    OperatingSystem = response['Reservations'][0]['Instances'][0]['Platform']
                except KeyError as error:
                    OperatingSystem = "Linux"
                #csvDataList.append(a)
                print (a)
                print("PrivateIP:",PrivateIP)
                print("PublicIP:",PublicIP)
                print("PrivateDNS:",PrivateDNS)
                print("PublicDNS:",PublicDNS)
                print("OS:",OperatingSystem)
                data1 = [accid, region, a,cmndid ]
                with open('outputFileName', 'a') as f:
                        writer = csv.writer(f)
                        writer.writerow(data1)
                        f.close()
                
                key = cmndid+"/"+a+outputFolderName
                print ("key:", key)
                try:    
                        i = 0
                        while True:
                            try :
                                result = s3Client.get_object(Bucket=bucketName, Key=key)
                                out = result["Body"].read().decode()
                                if 'Unsupported' not in out:
                                    Status = "Success"
                                else: Status = "Unsupported"
                                break
                            except Exception as e:
                                print (i,' ',e)
                                i = i + 1
                                time.sleep(20)
                                if(i == 5):
                                    Status = "Failed"
                                    result = None
                                    break
                                    #raise Exception(e)
                        if result is not None:
                            print ("result")
                            print (result)
                            print (out)

                            if 'Reboot is required, agent installation is skipped' in out:
                                print('VM is Pending rebooot...')
                                Status = 'Skipped'
                            else:
                                pass
                        else:
                            print ('result is None')
                            out = 'None'

                        data2 = [accid, region, a,PrivateIP,PrivateDNS,PublicIP,PublicDNS,OperatingSystem,Status,'alert_frequency','email_ids' ]
                        with open('VMDetailsFile', 'a') as f:
                                writer = csv.writer(f)
                                writer.writerow(data2)
                                f.close()

                        data = [accid, region, a, out]
                        with open('outputFileName', 'a') as f:
                                writer = csv.writer(f)
                                writer.writerow(data)
                                f.close()


                except Exception as e:
                    print ("error:",e)
                    error.append(e)
                    data = [accid, region, a, e]
                    with open('outputFileName', 'a') as f:
                            writer = csv.writer(f)
                            writer.writerow(data)
                            f.close()
        except Exception as e:
            #error.append(e)
            print (e)
        return 'success'

    except Exception as e:
        #error.append(e)
        print (e)
    return 'success'
    
def GetMasterRoleCredentials(AccessKey,SecretAccessKey ) :

    # Login through Given Credentials 
    stsclient = boto3.client('sts',
                region_name = 'us-east-1' ,  
                aws_access_key_id = AccessKey,  
                aws_secret_access_key = SecretAccessKey,  
    )
    try:
        response = stsclient.get_session_token(
            DurationSeconds=900
        )
        local_role_credentials = response['Credentials']

        # Assume Role in same account to get Fed Roles
        #arn:aws:iam::835377776149:role/CrossAccountAccessForJenkinsRole
        master_account_id= "835377776149"    
        session_name = master_account_id    
        master_account_role = "CrossAccountAccessForJenkinsRole"
        master_role_arn = "arn:aws:iam::" + master_account_id + ":role/" + master_account_role    
        master_role = assume_role(master_role_arn, session_name,local_role_credentials)    
        master_role_credentials = master_role['Credentials']  
    except: return 'credentials'
    return 'success'

#####################################################
# Create SSM document files from template
#####################################################
def CreateSSMFileFromTemplate(AccountId):
    print('Creating tag files ...')
    data1 = '''
    {
      "schemaVersion": "2.2",
      "description": "InstallTripWireOnLinux",
      "mainSteps": [
          {
          "action": "aws:runShellScript",
          "name": "CheckAndInstallTripWireOnLinux",
          "precondition": {
            "StringEquals": [
              "platformType",
              "Linux"
            ]
          },
          
          "inputs": {
            "runCommand": [
              "yum install wget -y &> /dev/null",
              "yum install dos2unix -y &> /dev/null",
              "mkdir /etc/tripwire",
              "wget -O /etc/tripwire/metadata.yml https://{{ account_id }}-ssm-bucket.s3.amazonaws.com/metadata.yml &> /dev/null",
              "cd /tmp",
              "wget https://wk-software-install.s3.amazonaws.com/tripwire/scripts/InstallAgentOnLinux.sh &> /dev/null",
              "dos2unix InstallAgentOnLinux.sh &> /dev/null",
              "chmod 777 InstallAgentOnLinux.sh",
              "./InstallAgentOnLinux.sh",
              "yum remove dos2unix -y &> /dev/null"
            ]
          }
        }
      ]
    }
    '''

    try:
        tm1 = Template(data1)
        tm1.stream(account_id=AccountId).dump('TripwireLinuxInstall.json')
        print ('SSM document for Linux created')
    except: return "error"
    return 'Success'
    '''tm2 = Template(data2)
    tm2.stream(account_id=account_id).dump('TripwireWindowsInstall.json')
    print ('SSM document for Windows created')
    '''
    

#####################################################
# Create Tag file
#####################################################
def CreateTagFile(buisnessUnit, cloudEnvironment, programInitiative, subscriptionNumber):
    print('Creating tag file ...')
    data = '''
    {
        tagSets :
        {
        Business Unit : [{{ business_unit }}],
        Cloud Environment : [{{ cloud_environment }}],
        GBS VM Subscription Name : [{{ subscription_name }}],
        GBS VM Subscription Number: [{{ subscription_number }}],
        Program-Initiative: [{{ program_initiative }}]
        }
    }
    '''

    tm = Template(data)
    tm.stream(business_unit=buisnessUnit,
              cloud_environment=cloudEnvironment,
              subscription_number="aws_"+subscriptionNumber,
              program_initiative=programInitiative).dump('metadata.yml')
    print ('Tag file created')
    return 'Success'

#############################################################################
# Check if correct agent version there is in the bucket
#############################################################################
def CheckAgentVersion(BucketName, FileName, Credentials):

    if Credentials == None:
        s3_client = boto3.client('s3')
    else:
        s3_client = boto3.client('s3',
                          aws_access_key_id=Credentials['AccessKeyId'],
                          aws_secret_access_key=Credentials['SecretAccessKey'],
				    	  aws_session_token= Credentials['SessionToken'])
    key = FileName

    try:
        s3_client.Object(BucketName, key).load()
        
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print("Doesn't exist")
            raise Exception("There is no correct agent version in the bucket")
        else:
            print ("Oops something wrong...")
    else:
        print("Axon agent version is correct")
        return 'Bucketname'
#!/bin/bash

AgentConfFile="twagent.conf"
AgentLicenseFile="registration_pre_shared_key.txt"

cd /tmp

# Check if CentOS/RedHat
if [[ -L "/etc/redhat-release" ||  -e "/etc/redhat-release" ]]; then
    yum install wget -y
    # Centos
    if [[ -e "/etc/centos-release" ]]; then
    # Check for centos version
        if grep -q '7\.' /etc/centos-release; then
            # Version is 7, do uninstall
            echo "CentOS 7 detected. Uniinstalling Axon Agent..."
			#first stop the service
			/sbin/service tripwire-axon-agent stop
            AxonAgentPkg="axon-agent"
            RHELDriverPkg="tw-eg-driver-rhel"
            RHELServicePkg="tw-eg-service"
            RHELSELinuxPkg="tripwire-axon-agent-selinux-policy"
            echo "Uninstalling  $AxonAgentPkg ..." 
            rpm -e $AxonAgentPkg
            echo "Uninstalling  $RHELServicePkg ..." 
            rpm -e $RHELServicePkg
            echo "Uninstalling  $RHELDriverPkg ..." 
            rpm -e $RHELDriverPkg
			echo "Uninstalling  $RHELSELinuxPkg ..." 
            rpm -e $RHELSELinuxPkg
            cd  /etc/tripwire/
            if [ -f "$AgentConfFile" ]; then
                rm $AgentConfFile
            fi
            if [ -f "$AgentLicenseFile" ]; then
                rm $AgentLicenseFile
            fi
    
        elif grep -q '6\.' /etc/centos-release; then
        # Version is 6, do uninstall
            echo "CentOS 6 detected. Uninstalling Axon Agent..."
			#first stop the service
			/sbin/service tripwire-axon-agent stop

            AxonAgentPkg="axon-agent"
            RHELDriverPkg="tw-eg-driver-rhel"
            RHELServicePkg="tw-eg-service"
            RHELSELinuxPkg="tripwire-axon-agent-selinux-policy"
            echo "Uninstalling  $AxonAgentPkg ..." 
            rpm -e $AxonAgentPkg
            echo "Uninstalling  $RHELServicePkg ..." 
            rpm -e $RHELServicePkg
            echo "Uninstalling  $RHELDriverPkg ..." 
            rpm -e $RHELDriverPkg
			echo "Uninstalling  $RHELSELinuxPkg ..." 
            rpm -e $RHELSELinuxPkg
            cd  /etc/tripwire/
            if [ -f "$AgentConfFile" ]; then
                rm $AgentConfFile
            fi
            if [ -f "$AgentLicenseFile" ]; then
                rm $AgentLicenseFile  
            fi
       else
            echo "Unsupported version of CentOS detected. Exiting..."
            exit 1
        fi

    # RHEL
    else
        # RHEL 7
        if grep -q '7\.' /etc/redhat-release; then
            echo "RHEL 7.x detected. Axon agent..." 
			#first stop the service
			/sbin/service tripwire-axon-agent stop

            AxonAgentPkg="axon-agent"
            RHELDriverPkg="tw-eg-driver-rhel"
            RHELServicePkg="tw-eg-service"
            RHELSELinuxPkg="tripwire-axon-agent-selinux-policy"
            echo "Uninstalling  $AxonAgentPkg ..." 
            rpm -e $AxonAgentPkg
            echo "Uninstalling  $RHELServicePkg ..." 
            rpm -e $RHELServicePkg
            echo "Uninstalling  $RHELDriverPkg ..." 
            rpm -e $RHELDriverPkg
			echo "Uninstalling  $RHELSELinuxPkg ..." 
            rpm -e $RHELSELinuxPkg
            cd  /etc/tripwire/
            if [ -f "$AgentConfFile" ]; then
                rm $AgentConfFile
            fi
            if [ -f "$AgentLicenseFile" ]; then
                rm $AgentLicenseFile
            fi
        # RHEL 6
        elif grep -q '6\.' /etc/redhat-release; then
            echo "RHEL 6.x detected. Axon agent..."
			#first stop the service
			/sbin/service tripwire-axon-agent stop
			#first stop the service
			/sbin/service tripwire-axon-agent stop
            AxonAgentPkg="axon-agent"
            RHELDriverPkg="tw-eg-driver-rhel"
            RHELServicePkg="tw-eg-service"
            RHELSELinuxPkg="tripwire-axon-agent-selinux-policy"
            echo "Uninstalling  $AxonAgentPkg ..." 
            rpm -e $AxonAgentPkg
            echo "Uninstalling  $RHELServicePkg ..." 
            rpm -e $RHELServicePkg
            echo "Uninstalling  $RHELDriverPkg ..." 
            rpm -e $RHELDriverPkg
			echo "Uninstalling  $RHELSELinuxPkg ..." 
            rpm -e $RHELSELinuxPkg
            cd  /etc/tripwire/
            if [ -f "$AgentConfFile" ]; then
                rm $AgentConfFile
            fi
            if [ -f "$AgentLicenseFile" ]; then
                rm $AgentLicenseFile
            fi
        else
            echo "Unsupported version of RHEL detected. Exiting..." 
            exit 1
        fi
    fi
# Check if Ubuntu
elif [[ "$(lsb_release --id -s)" = "Ubuntu" ]]; then
    echo "Ubuntu detected. Axon agent..."
	#first stop the service
	/usr/sbin/service tripwire-axon-agent stop
    AxonAgentPkg="axon-agent"
    RHELDriverPkg="tw-eg-driver-debian"
    RHELSevicePkg="tw-eg-service"
    echo "Uninstalling  $AxonAgentPkg ..." 
    dpkg -P $AxonAgentPkg
    echo "Uninstalling  $RHELSevicePkg ..." 
    dpkg -P $RHELSevicePkg
    echo "uninstalling  $RHELDriverPkg ..." 
    dpkg -P $RHELDriverPkg
    cd  /etc/tripwire/
    if [ -f "$AgentConfFile" ]; then
        rm $AgentConfFile
    fi
    if [ -f "$AgentLicenseFile" ]; then
        rm $AgentLicenseFile
    fi

# Check if Debian
elif [[ "$(lsb_release --id -s)" = "Debian" ]]; then 
    echo "Debian detected. Axon agent..."
	#first stop the service
	/usr/sbin/service tripwire-axon-agent stop
    AxonAgentPkg="axon-agent"
    RHELDriverPkg="tw-eg-driver-debian"
    RHELSevicePkg="tw-eg-service"
    echo "Uninstalling  $AxonAgentPkg ..." 
    dpkg -P $AxonAgentPkg
    echo "Uninstalling  $RHELSevicePkg ..." 
    dpkg -P $RHELSevicePkg
    echo "uninstalling  $RHELDriverPkg ..." 
    dpkg -P $RHELDriverPkg
    cd  /etc/tripwire/
    if [ -f "$AgentConfFile" ]; then
        rm $AgentConfFile
    fi
    if [ -f "$AgentLicenseFile" ]; then
        rm $AgentLicenseFile
    fi
# Unsupported distribution
else
    echo "Unsupported distribution, or unable to detect. Exiting..."
    exit 1
fi

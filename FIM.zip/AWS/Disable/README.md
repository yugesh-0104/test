Purpose
Uninstall Tripwire agents

Implementation
"UninstallAgentOnLinux.sh" is script to uninstall Tripwire Agent from Linux VM's and is placed in https://wk-software-install.s3.amazonaws.com/tripwire/scripts/UninstallAgentOnLinux.sh 

"UnInstallAxonOnWindows.ps1" is script to uninstall Tripwire Agent from Windows VM's and is placed in https://wk-software-install.s3.amazonaws.com/tripwire/scripts/UnInstallAxonOnWindows.ps1 

AWS System Manager downloads the scripts from S3 and runs it on VM's.
# Uninstall Tripwire on Linux and Windows VMs
import boto3
import csv
from datetime import datetime
from pytz import timezone
import threading
import subprocess
import argparse
import sys,os,json
import  botocore
import time, logging
from os import listdir
from os.path import isfile, join

mypath ="./"
#Software related configurations
SSMAgentDocument=""
header1 = ["Account-id","Region","Instance-id","Tripwire"]
header2 = ["Account-id","Region","Instance-id","PrivateIP","PrivateDNS","PublicIP","PublicDNS","Status"]
outputFileName = 'TripwireUninstallLogs'+datetime.now(timezone('UTC')).strftime("%d%m%Y%I%M%S")+'.csv'
VMDetailsFile = 'AgentUninstalledVMdetailsFile'+datetime.now(timezone('UTC')).strftime("%d%m%Y%I%M%S")+'.csv'
parameters_file = 'uninstall.parameters.json'


outputS3BucketName='-ssm-bucket'


error =[]
csvDataList=[]

### --- Parse Input Arguments --- ###
parser = argparse.ArgumentParser(description='Install Tripwire Agent')
parser.add_argument('--aws_access_key_id', required=True, type=str, help='aws_access_key_id is MANDATORY argumet.')
parser.add_argument('--aws_secret_access_key', required=True, type=str, help='aws_secret_access_key is MANDATORY argumet.')
parser.add_argument('--aws_session_token', type=str, help='Optional aws_session_token.')

args = parser.parse_args()

with open(outputFileName, 'a') as f:
 writer = csv.writer(f)
 writer.writerow(header1)
f.close()

with open(VMDetailsFile, 'a') as f:
 writer = csv.writer(f)
 writer.writerow(header2)
f.close()

 
####################### Getting Credentials ###########################3
def get_account_credentials(account_id, master_role_credentials):
    role = get_fedRoles_operations_role(account_id,master_role_credentials) # Added for Jump Account Integration
    account_role_arn = "arn:aws:iam::" + account_id + ":role/"+role # Modified for Jump Account Integration
    account_role = assume_role(account_role_arn, account_id, master_role_credentials)
    account_credentials = account_role['Credentials']
    return account_credentials
    
def get_fedRoles_operations_role(account_id,credentials):
    print ("Calling DB ")
    keyval = account_id+"-WKFedRoles-Operations"
    print (keyval)
    dynamodb = boto3.resource('dynamodb',
        region_name='us-east-1',
        aws_access_key_id     = credentials['AccessKeyId'],
        aws_secret_access_key = credentials['SecretAccessKey'],
        aws_session_token     = credentials['SessionToken'],
        )
    
    table = dynamodb.Table('WK-FedRoles')
    
    response = table.get_item(
        
        Key={
            'AccountFedRole':  keyval,
        },
        AttributesToGet=['RoleName']
        )
    #print response
    print ('WKFedRoles-Operations for ' ,account_id , 'is ' , response['Item']['RoleName'])
    role = response['Item']['RoleName']
    return role

def assume_role(role_arn, session_name, credentials):
    sts_client = boto3.client('sts',
        aws_access_key_id = credentials['AccessKeyId'],
        aws_secret_access_key = credentials['SecretAccessKey'],
        aws_session_token = credentials['SessionToken']
    )
    
    
    assumedRoleObject = sts_client.assume_role(    
        RoleArn=role_arn,
        RoleSessionName=session_name,
        DurationSeconds=990
    )
    return assumedRoleObject
    
def new_sts_func( accountid,rolename ):
        arn='arn:aws:iam::'+str(accountid)+':role/'+rolename
        session_name='NewSession-'+str(accountid)
        client = boto3.client('sts',region_name='us-east-2')
        response = client.assume_role(
        RoleArn=arn,
        RoleSessionName=session_name,
        )
        return response['Credentials']

def sts_func1( accountid,rolename,accesskey,secretkey,token ):
        arn='arn:aws:iam::'+str(accountid)+':role/'+rolename
        session_name='NewSession-'+str(accountid)
        client = boto3.client('sts',region_name='us-east-2',aws_access_key_id=accesskey,aws_secret_access_key=secretkey,aws_session_token=token)
        response = client.assume_role(
        RoleArn=arn,
        RoleSessionName=session_name,
        )
        return response['Credentials']

########################################################
#1. Checking SSM document 
########################################################

def checkSSMDocument(docName, region, credentials):
  ssm = boto3.client('ssm',region_name=region,
                 aws_access_key_id     = credentials['AccessKeyId'],
                 aws_secret_access_key = credentials['SecretAccessKey'],
                 aws_session_token     = credentials['SessionToken'],)
    
  try:
    response = ssm.describe_document(Name=docName)
  except botocore.exceptions.ClientError as e:
    print  (e.response['Error']['Message'])
    return ''
  return response

  
#######################################################################
#1. Download SSM document (if uploaded on S3)
#######################################################################
  
def downloadDocument(bucketName, fileName, localPath, master_role_credentials):
  print ("file to be downloaded: ", fileName)
#  account_cred= get_account_credentials(s3acc_id,master_role_credentials)
  role = get_fedRoles_operations_role(account_id,master_role_credentials)
  account_cred = sts_func1(SSMDocumentAccount,role,
                 master_role_credentials['AccessKeyId'],
                 master_role_credentials['SecretAccessKey'],
                 master_role_credentials['SessionToken'],)

  s3 = boto3.resource('s3', 
                 aws_access_key_id     = account_cred['AccessKeyId'],
                 aws_secret_access_key = account_cred['SecretAccessKey'],
                 aws_session_token     = account_cred['SessionToken'],)
    
  try:
      s3.Bucket(bucketName).download_file(fileName, localPath)
      print ("success")
  except botocore.exceptions.ClientError as e:
      print (e.message)
      if e.response['Error']['Code'] == "404":
          print("The object does not exist.")
      else:
          raise

#######################################################################
#1. Create SSM document through API
#######################################################################

def createDocument(localPath, region, docName, credentials):
  content = ''
  print ("Creating Document..",docName)
  print(localPath)
  onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
  print(onlyfiles)
  try:
      with open(localPath) as ssmDocumentFile:
            content = ssmDocumentFile.read()
            print (content)
            ssm = boto3.client('ssm', region_name=region,
                  aws_access_key_id     = credentials['AccessKeyId'],
                  aws_secret_access_key = credentials['SecretAccessKey'],
                  aws_session_token     = credentials['SessionToken'],)

            response = ssm.create_document(Name = docName, Content = content, DocumentType = "Command")
            #print response
            ssmDocumentFile.close()
             
  except Exception as e:
        print (e.message)

#######################################################################
#1. Delete SSM document through API
#######################################################################

def deleteDocument(docName, region, credentials):
  onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
  print(onlyfiles)
  ssm = boto3.client('ssm', region_name=region,
                      aws_access_key_id     = credentials['AccessKeyId'],
                      aws_secret_access_key = credentials['SecretAccessKey'],
                      aws_session_token     = credentials['SessionToken'])
  try:
    ssm.modify_document_permission(Name=docName, PermissionType='Share', AccountIdsToRemove=["All"])
    response = ssm.delete_document(Name=docName)
    print ("document deleted: ", docName)
  except  Exception as e:
    print (e.message)

#######################################################################
#1. createOutputBucket
#######################################################################

def createOutputBucket(accountId, master_role_credentials):
  
  SSMOutputAccount = accountId
  bucketName=str(accountId)+outputS3BucketName
  print ("Output bucket to be created: ", bucketName)
  account_Id = str(accountId)
  role = get_fedRoles_operations_role(account_Id,master_role_credentials)
  account_cred = sts_func1( SSMOutputAccount,role,
                 master_role_credentials['AccessKeyId'],
                 master_role_credentials['SecretAccessKey'],
                 master_role_credentials['SessionToken'],)


  s3 = boto3.resource('s3',
                      aws_access_key_id     = account_cred['AccessKeyId'],
                      aws_secret_access_key = account_cred['SecretAccessKey'],
                      aws_session_token     = account_cred['SessionToken'],)
  try:
    if (s3.Bucket(bucketName) in s3.buckets.all()) == False:
      response=s3.create_bucket(ACL='public-read-write', Bucket=bucketName)
      print ("Bucket Created: ",response)
    else:
      print ("The bucket: ",bucketName," already exists...")
 
  except Exception as e:
    print (e.message)
  return bucketName

######################################################################################
#1. Check if SSM document already there
#2.
######################################################################################
def createSSMDocuments(SSMAgentDocument,JsonDocument,region, credentials, master_role_credentials, currentAccount):
  print ("Test")
  print (SSMAgentDocument)
  status = checkSSMDocument(SSMAgentDocument, region, credentials)
  
  if status == '':
    print ("Inside if")
    
    localPath=JsonDocument # please comment it during run in Unix
    #key=inputKey+LinuxJsonDocument
    #downloadDocument(inputS3BucketName, key, localPath, master_role_credentials)
    onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    print(onlyfiles)
    createDocument(localPath, region, SSMAgentDocument, credentials)
  else:
    print ("Inside else")
    
    localPath=JsonDocument # please comment it during run in Unix
    #key=inputKey+LinuxJsonDocument
    #downloadDocument(inputS3BucketName, key, localPath, master_role_credentials)
    deleteDocument(SSMAgentDocument, region, credentials)
    createDocument(localPath, region, SSMAgentDocument, credentials,)
  print ("creating output bucket...")
  bucketName = createOutputBucket(currentAccount,master_role_credentials)
  return bucketName

  # Getting VM Details file name as output Variable
def getFileNameAsOutputVariable(VMDetailsFile,outputFileName ) :
    print (VMDetailsFile)
    command_output1 = "##vso[task.setvariable variable=VMDetailsFileName;]"+VMDetailsFile
    print("command_output1:",command_output1)
                        
    rc = subprocess.call(command_output1,shell=True)
    print (outputFileName)
    command_output2 = "##vso[task.setvariable variable=LogFileName;]"+outputFileName
    print("command_output1:",command_output2)
                        
    rc = subprocess.call(command_output2,shell=True)
    print(os.path.abspath(VMDetailsFile))
    onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    print(onlyfiles)
   

##################################################################################
#1. Create SSM Document in the Account 
#2. 
#
##################################################################################


def install_tripwire(accountlist, region_list,instanceids,master_credentials):
    for acc in accountlist:
        accid = int(acc)
        csvDataList.append(accid)
        print ("Gathering data for account id: ",acc)
        print ("account_info",acc)
        try:
            account_cred = get_account_credentials(acc, master_credentials)
            temp_access1 = account_cred['AccessKeyId'],
            temp_secret1 = account_cred['SecretAccessKey'],
            temp_token1 = account_cred['SessionToken']
            
            print ("account_info")
            for region in region_list:
                csvDataList.append(region)
                
                ssm_client = boto3.client('ssm',region_name=region,
                            aws_access_key_id     = account_cred['AccessKeyId'],
                            aws_secret_access_key = account_cred['SecretAccessKey'],
                            aws_session_token     = account_cred['SessionToken'],)
                print ("ssm")
                ssm_id_unix = []
                ssm_id_win = []
                all_ssm_id = []
                ssm_id_VM = []
                
                
                response = ssm_client.describe_instance_information()
                # there may be more.use token
                getVMDetails (response ,ssm_id_unix , ssm_id_win ,all_ssm_id,instanceids)
                while "NextToken" in response.keys():
                    response = ssm_client.describe_instance_information(NextToken=response['NextToken'])
                    
                    getVMDetails (response ,ssm_id_unix , ssm_id_win ,all_ssm_id, instanceids)
                

                s3Client= boto3.client('s3',
                            aws_access_key_id     = account_cred['AccessKeyId'],
                            aws_secret_access_key = account_cred['SecretAccessKey'],
                            aws_session_token     = account_cred['SessionToken'],)
                 

                                    
                print ("For region:",region)
                print ("Instances with SSM:",all_ssm_id)
                print ("Windows Instances with SSM:",ssm_id_win)
                print ("Linux Instances with SSM:",ssm_id_unix)
                
            
                while ssm_id_unix != []:
                    SSMAgentDocument="TripwireLinuxUninstall"
                    JsonDocument= 'TripwireLinuxUninstall.json'
                    outputFolderName='/awsrunShellScript/CheckAndUninstallTripWireOnLinux/stdout'
                    bucketName = createSSMDocuments(SSMAgentDocument,JsonDocument,region, account_cred, master_credentials, accid)
                    print ("bucketName")
                    processVMs(ssm_id_unix,all_ssm_id,SSMAgentDocument,outputFolderName,bucketName,ssm_client,s3Client,accid, region,master_credentials)
                    break
                while ssm_id_win != []:
                    SSMAgentDocument="TripwireWinUninstall"
                    JsonDocument= 'TripwireWindowsUninstall.json'
                    outputFolderName='/awsrunPowerShellScript/PatchWindows/stdout'
                    bucketName = createSSMDocuments(SSMAgentDocument,JsonDocument,region, account_cred, master_credentials, accid)
                    print ("bucketName")
                    processVMs(ssm_id_win,all_ssm_id,SSMAgentDocument,outputFolderName,bucketName,ssm_client,s3Client,accid, region,master_credentials)
                    break
                while ssm_id_unix == [] and ssm_id_win ==[ ] :
                    data = [accid, region, '-', 'No UnixVM or windows with SSM enabled found']
                    with open(outputFileName, 'a') as f:
                            writer = csv.writer(f)
                            writer.writerow(data)
                            f.close()
    
        except Exception as e:
            print ("error ",e,"on",accid)
            with open(r'unreachable.csv', 'a') as f:
                    writer = csv.writer(f)
                    writer.writerow((accid,e))
                    f.close()
    getFileNameAsOutputVariable(VMDetailsFile,outputFileName )
    

def getVMDetails (response ,ssm_id_unix , ssm_id_win ,all_ssm_id ,instanceids) :
    i = 0
    for instancelist in response["InstanceInformationList"]:
        
        i = i+1 
       
        InstanceId = instancelist["InstanceId"]
        InstanceIp = instancelist["IPAddress"]
        InstancePlatform = instancelist["PlatformType"]
        # Adding all SSM enabled VMs
        InstanceDetail = {} 
        InstanceDetail[InstanceId ] = InstancePlatform
        InstanceDetail['IP' ] = InstanceIp
        all_ssm_id.append(InstanceDetail)
        
        #print 'InstancePlatform:',InstancePlatform
        if InstancePlatform == 'Linux':
            if(len(instanceids) == 0):
                ssm_id_unix.append(InstanceId)
                
            else :
                if(InstanceId in instanceids): # Add only those ids which are part of Instance id
                    #print 'Adding id to unix list',InstanceId
                    ssm_id_unix.append(InstanceId)
                         
        else:
            if(len(instanceids) == 0):   
                ssm_id_win.append(InstanceId)
                
            else:
                if(InstanceId in instanceids):
                    ssm_id_win.append(InstanceId)

    return ssm_id_unix, ssm_id_win


def processVMs(ssm_id_VM,all_ssm_id,SSMAgentDocument,outputFolderName,bucketName,ssm_client,s3Client,accid, region,master_credentials) :
    try:
        print ("SendCommand in one go for all instances")
        print (ssm_id_VM)
        response_VM = ssm_client.send_command( InstanceIds=ssm_id_VM, DocumentName=SSMAgentDocument, OutputS3BucketName=bucketName )
        print ("response: ",response_VM)
        cmndid = str(response_VM["Command"]["CommandId"])
        print ("cmd:",cmndid)
        acc = str(accid)
        try:
            account_cred = get_account_credentials(acc, master_credentials)
            temp_access1 = account_cred['AccessKeyId'],
            temp_secret1 = account_cred['SecretAccessKey'],
            temp_token1 = account_cred['SessionToken']
        
            ec2client = boto3.client('ec2',region_name=region,
                            aws_access_key_id     = account_cred['AccessKeyId'],
                            aws_secret_access_key = account_cred['SecretAccessKey'],
                            aws_session_token     = account_cred['SessionToken'],)
        
            for instid in ssm_id_VM:
                a = str(instid)
                response = ec2client.describe_instances(InstanceIds=[instid])
                print("Describing Instances")
                print(response)
                try:
                    PrivateIP = response['Reservations'][0]['Instances'][0]['PrivateIpAddress']
                except KeyError as error:
                    PrivateIP = " "
                try:
                    PrivateDNS = response['Reservations'][0]['Instances'][0]['PrivateDnsName']
                except KeyError as error:
                    PrivateDNS = " "   
                try:
                    PublicIP = response['Reservations'][0]['Instances'][0]['PublicIpAddress']
                except KeyError as error:
                    PublicIP = " "
                try:
                    PublicDNS = response['Reservations'][0]['Instances'][0]['PublicDnsName']
                except KeyError as error:
                    PublicDNS = " "
                csvDataList.append(a)
                print (a)
                print("PrivateIP:",PrivateIP)
                print("PublicIP:",PublicIP)
                print("PrivateDNS:",PrivateDNS)
                print("PublicDNS:",PublicDNS)
                data1 = [accid, region, a,cmndid ]
                with open(outputFileName, 'a') as f:
                        writer = csv.writer(f)
                        writer.writerow(data1)
                        f.close()
                
                key = cmndid+"/"+a+outputFolderName
                print ("key:", key)
                try:    
                        i = 0
                        while True:
                            try :
                                result = s3Client.get_object(Bucket=bucketName, Key=key)
                                break
                            except Exception as e:
                                print (i,' ',e)
                                i = i + 1
                                time.sleep(20)
                                if(i == 5):
                                    Status = "Failed"
                                    data2 = [accid, region, a,PrivateIP,PrivateDNS,PublicIP,PublicDNS,Status]
                                    with open(VMDetailsFile, 'a') as f:
                                            writer = csv.writer(f)
                                            writer.writerow(data2)
                                            f.close()
                                    raise Exception(e)
                    
                        print ("result")
                        out = result["Body"].read().decode()
                        print (out)
                        if 'Unsupported' in out:
                            Status = "Unsupported"
                        else:
                            Status = "Success"
                        data2 = [accid, region, a,PrivateIP,PrivateDNS,PublicIP,PublicDNS,Status ]
                        with open(VMDetailsFile, 'a') as f:
                                writer = csv.writer(f)
                                writer.writerow(data2)
                                f.close()
# #                                                               res= out.replace("\n", " ")
# #                                                               print res
                        data = [accid, region, a, out]
                        with open(outputFileName, 'a') as f:
                                writer = csv.writer(f)
                                writer.writerow(data)
                                f.close()


                except Exception as e:
                    print ("error:",e)
                    error.append(e)
                    data = [accid, region, a, e]
                    with open(outputFileName, 'a') as f:
                            writer = csv.writer(f)
                            writer.writerow(data)
                            f.close()
        except Exception as e:
            error.append(e)
            print (e)

    except Exception as e:
        error.append(e)
        print (e)
    
def getMasterRoleCredentials(access_key,secret_access_key ) :
    # Login through Given Credentials 
    cwd = os.getcwd()
    print("Current Directory",cwd)
    stsclient = boto3.client('sts',
                region_name = 'us-east-1' ,  
                aws_access_key_id = access_key,  
                aws_secret_access_key = secret_access_key,  
    )
    response = stsclient.get_session_token(
        DurationSeconds=900
    )
    local_role_credentials = response['Credentials']

    # Assume Role in same account to get Fed Roles
    #arn:aws:iam::835377776149:role/CrossAccountAccessForJenkinsRole
    master_account_id= "835377776149"    
    session_name = master_account_id    
    master_account_role = "CrossAccountAccessForJenkinsRole"
    master_role_arn = "arn:aws:iam::" + master_account_id + ":role/" + master_account_role    
    master_role = assume_role(master_role_arn, session_name,local_role_credentials)    
    master_role_credentials = master_role['Credentials']  
    return master_role_credentials    


#####################################################################
##############             Entry Point       ########################
#####################################################################


print (args.aws_access_key_id)
print (args.aws_secret_access_key)
# Please change here accordingly 
master_role_credentials =  getMasterRoleCredentials(args.aws_access_key_id, args.aws_secret_access_key )

with open (parameters_file) as json_data:
        parameters = dict(json.load(json_data))['parameters']

accountlist = parameters['account_id'].replace(',', ' ').split()
region_list = parameters['region_name'].replace(',', ' ').split()
instance_list = parameters['instance_ids'].replace(',', ' ').split()

# Install it
install_tripwire(accountlist, region_list ,instance_list ,master_role_credentials)

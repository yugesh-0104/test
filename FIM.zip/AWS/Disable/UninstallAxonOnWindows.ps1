$S3Path="https://software-install.s3.amazonaws.com/tripwire/"
$FileToInstall = "Axon_Agent_x64.msi"
$ConfigurationFile = "twagent.conf"
$LicenseFile = "registration_pre_shared_key.txt"
$CopyFileLocation = "C:\ProgramData\Tripwire\agent\config\"

$twagentconf = $CopyFileLocation+"twagent.conf"
$registration_pre_shared_key = $CopyFileLocation+"registration_pre_shared_key.txt"

$DownloadFileLink = $S3Path+"Windows/Axon_Agent_x64.msi"

$PathToDownloadFile = "C:\temp\"
$FileToInstallPath = ($PathToDownloadFile+$FileToInstall)

Write-Host "stopping  TripwireAxonAgent "
net stop TripwireAxonAgent

Write-Host "Downloading agent file "
#Download agent file 
if(!(Test-Path $PathToDownloadFile)) { mkdir $PathToDownloadFile}
cd $PathToDownloadFile;
$client = new-object System.Net.WebClient;
$client.DownloadFile("$DownloadFileLink","$FileToInstallPath");


#Uninstall agent agent file 
Start-process "msiexec.exe" -arg "/x $FileToInstall /qn" -Wait
cd C:\ProgramData\Tripwire\agent\config

Write-Host "Deleting config files"
del $twagentconf
del $registration_pre_shared_key

Write-Host "Deleting agent MSI"
cd c:\temp
del $FileToInstall
import os
import mock
import pytest
import file1
import datetime
import boto3
import csv
from unittest.mock import Mock
import botocore.session
from jinja2 import Template
from botocore.stub import Stubber, ANY
 
##################################################################################################
##############                Test Case for Get Account Credentials                    ###########
##################################################################################################
def test_GetAccountCredentials(mocker):
    Credential = {
        'AccessKeyId': '12345678',
        'AccessScretKeyId': 'string',
        'Servicetoken': 'string'
    }
    Credential1 = {
        'AccessKeyId': '87654321',
        'AccessScretKeyId': 'string',
        'Servicetoken': 'string'
    }
    response = file1.GetAccountCredentials(AccountId='123456789',MasterRoleCredentials=Credential)      
    assert response == Credential

def test_GetAccountCredentials(mocker):
    Credential1 = {
        'AccessKeyId': '87654321',
        'AccessScretKeyId': 'string',
        'Servicetoken': 'string'
    }
    response = file1.GetAccountCredentials(AccountId='123456789',MasterRoleCredentials={})     
    assert response == 'InvalidCredentials'

##################################################################################################
##############                Test Case for Assume_Role                                ###########
##################################################################################################
def test_assume_role(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }

    response = file1.assume_role(role_arn="test_role_arn",
                                 session_name="test_session_name", credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    assert response.return_value["Credentials"] == {
        'AccessKeyId': 'string',
        'SecretAccessKey': 'string',
        'SessionToken': 'string',
        'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
    }
test_assume_role


def test_assume_role_cred_none(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }

    response = file1.assume_role(role_arn="test_role_arn",
                                 session_name="test_session_name", credentials=None)
    assert response.return_value["Credentials"] == {
        'AccessKeyId': 'string',
        'SecretAccessKey': 'string',
        'SessionToken': 'string',
        'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
    }
test_assume_role_cred_none

##################################################################################################
##############                Test Case for New_Sts_Func                               ###########
##################################################################################################
def test_NewStsFunc(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.NewStsFunc(AccountId="234567891",
                                RoleName="test_role_name")
    assert response != {'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
            }

def test_NewStsFuncCred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.NewStsFunc(AccountId="234567891",
                                 RoleName="test_role_name")
    assert response != {} 

'''        
##################################################################################################
##############                Test Case for Sts_Func1                                  ###########
##################################################################################################
def test_new_sts_func1(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.sts_func1(accountid="234567891",
                                 rolename="test_role_name",
                                 accesskey="test",secretkey="test",token="test")
    assert response != {'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
            }

def test_new_sts_func1_cred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.sts_func1(accountid="234567891",
                                 rolename="test_role_name",
                                 accesskey="test",secretkey="test",token="test")
    assert response != {}


##################################################################################################
##############                Test Case for checkSSMDocument                           ###########
##################################################################################################
def test_checkSSMDocument(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'describe_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    #mocker.patch('file1.boto3.client',return_value= {})
    #mocker.patch ('describe_document', return_value = 'test_docname')
    file1.boto3.client('ssm').describe_document(docName='test_docname').return_value = {'Document': {'Name':'test_docname'}}
    response = file1.checkSSMDocument(docName='test_docname',region='us-east-1',credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})

    assert response.return_value['Document']['Name'] == 'test_docname'
test_checkSSMDocument


def test_checkSSMDocument_none(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'describe_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    #mocker.patch('file1.boto3.client',return_value= {})
    #mocker.patch ('describe_document', return_value = 'test_docname')
    file1.boto3.client('ssm').describe_document(docName='test_docname').return_value = {'Document': {'Name':'test_docname'}}
    response = file1.checkSSMDocument(docName='test_docname',region='us-east-1',credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})

    assert response.return_value['Document']['Name'] == 'test_docname'
test_checkSSMDocument_none



##################################################################################################
############## Test Case for Download SSM document (if uploaded on S3)            ################                                                     
##################################################################################################
'''
def test_downloadDocument(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('ssm').return_value = {}
    ssm_client = boto3.client('ssm')
    ssm_cli =  {
        
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)

        },
        'Document':{
            'Name' : "string"
        },
        'PackedPolicySize': 123
    }
    '''

##################################################################################################
##############         Test Case for Create SSM document through API              ################                                                     
##################################################################################################

def test_createDocument1(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('ssm').return_value = {}
    file1.boto3.client('ssm').create_document(docName='test_docname',DocumentType='test_content').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    
    with mock.patch('file1.open',mock.mock_open(read_data="ssmDocumentFile"),create=True) as mock_file1:
        response =  file1.createDocument(docName='test_docname',region='us-east-2',localPath='test_path',credentials=None)
    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_createDocument1

def test_createDocument2(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('ssm').return_value = {}
    file1.boto3.client('ssm').create_document(docName='test_docname',DocumentType='test_content').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    
    with mock.patch('file1.open',mock.mock_open(read_data="ssmDocumentFile"),create=True) as mock_file1:
        response =  file1.createDocument(docName='test_docname',region='us-east-2',localPath='test_path',credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_createDocument2
##################################################################################################
##############         Test Case for Delate SSM document through API              ################                                                    
##################################################################################################
def test_deleteDocument(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'create_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    file1.boto3.client('ssm').delete_document(docName='test_docname').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    response = file1.deleteDocument(docName='test_docname',region='us-east-2',credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_deleteDocument

def test_deleteDocument_cred(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'create_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    file1.boto3.client('ssm').delete_document(docName='test_docname').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    response = file1.deleteDocument(docName='test_docname',region='us-east-2',credentials=None)

    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_deleteDocument_cred
##################################################################################################
##############               Test Case for CreateOutputBucket                     ################                                                     
##################################################################################################

def test_createOutputBucket(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli =  {
        'Credential94' : {
            'AccessKeyId': '234567894',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
        },    
            'Location': 'string'  
    }
    file1.boto3.client('s3').createOutputBucket(AccountId="234567894",
                                            Master_role_credentials=s3_cli,
                                            DurationSeconds=990).return_value = s3_cli
                                             
    response = file1.createOutputBucket(AccountId="234567894",
                                        MasterRoleCredentials=None)
    try:
        response=s3_client.create_bucket(ACL='public-read-write', 
                                        Bucket='test_bucketName').return_value
    except Exception as e:
        print (e)
        return 'test_bucketName'
    
    assert response.return_value["Bucket"] == 'test_bucketName'

def test_createOutputBucket_Buck(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli =  {
        'Credential94' : {
            'AccessKeyId': '234567894',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
        },    
            'Location': 'string'  
    }
    file1.boto3.client('s3').createOutputBucket(AccountId="234567894",
                                            Master_role_credentials=s3_cli,
                                            DurationSeconds=990).return_value = s3_cli
                                             
    response = file1.createOutputBucket(AccountId="234567894",
                                        MasterRoleCredentials=None)
    try:
        response=s3_client.create_bucket(ACL='public-read-write', 
                                        Bucket=' ').return_value
    except Exception as e:
        print (e)
        return ' '
    
    assert response.return_value["Bucket"] == ' '


##################################################################################################
##############   Test Case for CreateOutputBucketCheck if SSM document already there #############                                                   
##################################################################################################
def test_createSSMDocuments(mocker):
   # mocker.patch.object(file1, 'boto3')
    mocker.patch('file1.checkSSMDocument',return_value= 'dummydocname')
    mocker.patch('file1.createDocument',return_value='dummydoccreate')
    mocker.patch('file1.deleteDocument',return_value='dummydocdeleted')
    mocker.patch('file1.createOutputBucket',return_value='dummycreateOutputBucket')
    response = file1.createSSMDocuments(SSMAgentDocument='test_SSMAgentDocument',
                            JsonDocument='test_jsondoc',
                            region='test_region',
                            credentials={},master_role_credentials={},currentAccount=12345777)
    assert response == "dummycreateOutputBucket"

def test_createSSMDocuments_Name(mocker):
   # mocker.patch.object(file1, 'boto3')
    mocker.patch('file1.checkSSMDocument',return_value= 'dummydocname')
    mocker.patch('file1.createDocument',return_value='dummydoccreate')
    mocker.patch('file1.deleteDocument',return_value='dummydocdeleted')
    mocker.patch('file1.createOutputBucket',return_value=' ')
    response = file1.createSSMDocuments(SSMAgentDocument='test_SSMAgentDocument',
                            JsonDocument='test_jsondoc',
                            region='test_region',
                            credentials={},master_role_credentials={},currentAccount=12345777)
    assert response == " "

##################################################################################################
##############   Test Case for Create SSM Document in the Account                    #############                                                   
##################################################################################################
def test_getFileNameAsOutputVariable(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.getFileNameAsOutputVariable(VMDetailsFile='test_VMfile',outputFileName='test_Outputfilename')
    with mock.patch('os.listdir') as mocked_listdir:
        mocked_listdir = ['test_listfile']
    response = file1.getFileNameAsOutputVariable(VMDetailsFile="test_VMfile",
                                                outputFileName="test_Outputfilename")
    assert response == 'success'
test_getFileNameAsOutputVariable


def test_getFileNameAsOutputVariable_Filename(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.getFileNameAsOutputVariable(VMDetailsFile='test_VMfile',outputFileName='')
    with mock.patch('os.listdir') as mocked_listdir:
        mocked_listdir = ['test_listfile']
    response = file1.getFileNameAsOutputVariable(VMDetailsFile=None,
                                                outputFileName=None)
    assert response == 'Failure'
test_getFileNameAsOutputVariable_Filename


##################################################################################################
##############   Test Case for Installing Tripwire agent on VMs                      #############                                                   
##################################################################################################

# Installing Tripwire agent on VMs
def test_install_tripwire(mocker):
    mocker.patch.object(file1, 'boto3')
    mocker.patch.object(file1,'csv')
    ssm_client = boto3.client('ssm',region_name='us-east-1')
    
    #writer = csv.writer('filehandel')
    s3_client = boto3.client('s3')
    file1.boto3.client('ssm').describe_instance_information().return_value = {'InstanceInformationList':[{'InstanceId': 'string','PlatformType': 'Linux','Name': 'string','AgentVersion': 'string'},], 'NextToken': 'string'}
    unix = ['dummyUnixId']
    win = ['dummyWinId']
    temp_cred =  {
        
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)

        },
        'DocumentDescription': {
            'Name': 'string'
        },
        'PackedPolicySize': 123
    }
    mocker.patch('file1.GetAccountCredentials',return_value=temp_cred)
    mocker.patch('file1.getVMDetails',return_value=[unix,win])
    mocker.patch('file1.checkAgentVersion',return_value=True)
    mocker.patch('file1.createSSMFileFromTemplate',return_value=True)
    mocker.patch('file1.createSSMDocuments',return_value='dummyssmbucket')
    mocker.patch('file1.createTagFile',return_value=True)
    mocker.patch('file1.uploadFileToBucket',return_value=True)
    mocker.patch('file1.processVMs',return_value=True)
    
    mocker.patch('file1.getFileNameAsOutputVariable',return_value='success')
    #mock = Mock('file1.getFileNameAsOutputVariable',return_value='success')
    file1.install_tripwire(accountlist=[1,2], region_list=['us-east-1'],instanceids=['id1','id2'],master_credentials={})
    #mocker.assert_called_once()
    file1.getFileNameAsOutputVariable.assert_called_once()


##################################################################################################
##############   Test Case for Getting VM details like OS type etc                   #############                                                   
##################################################################################################
def test_getVMDetails(mocker):
    mocker.patch.object(file1, 'boto3')
    #ssm_id_unix=[]
    #ssm_id_win=[]
    #all_ssm_id=[]
    #instanceids=[]

    resp = {
        'InstanceInformationList':[
        {
            'InstanceId': 'string',
            'PlatformName': 'string',
            'PlatformType': 'win',
            'Name': 'string'
        }
        ]
    }
    '''mocker.patch('file1.response',return_value= {})
    mocker.patch('file1.ssm_id_unix',return_value='dummydoccreate')
    mocker.patch('file1.ssm_id_win',return_value='dummydocdeleted')
    mocker.patch('file1.ssm_id_win',return_value='dummydocdeleted')
    mocker.patch('file1.instanceids',return_value='dummycreateOutputBucket')'''
    file1.getVMDetails(response=resp,ssm_id_unix=[123456],
                       ssm_id_win=[1223344],all_ssm_id=[1234455],instanceids=[556677])
    response = file1.getVMDetails(response=resp,ssm_id_unix=[123456],
                                  ssm_id_win=[1223344],all_ssm_id=[1234455],instanceids=[556677])
    assert response == 'win'

def test_getVMDetails_Unix(mocker):
    mocker.patch.object(file1, 'boto3')
    #ssm_id_unix=[]
    #ssm_id_win=[]
    #all_ssm_id=[]
    #instanceids=[]

    resp1 = {
        'InstanceInformationList':[
        {
            'InstanceId': 'string',
            'PlatformName': 'string',
            'PlatformType': 'unix',
            'Name': 'string'
        }
        ]
    }

    file1.getVMDetails(response=resp1,ssm_id_unix=[123456],
                       ssm_id_win=[1223344],all_ssm_id=[1234455],instanceids=[556677])
    response = file1.getVMDetails(response=resp1,ssm_id_unix=[123456],
                                  ssm_id_win=[1223344],all_ssm_id=[1234455],instanceids=[556677])
    assert response != 'unix'

##################################################################################################
##############   Test Case for ProcessVMs                                            #############                                                   
##################################################################################################
def test_processVMs(mocker):
    mocker.patch.object(file1, 'boto3')
    mocker.patch.object(file1,'csv')
    file1.boto3.client('ssm').return_value = {}
    file1.boto3.client('ec2').return_value = {}
    file1.boto3.client('s3').return_value = {}
    ssm_cmd = {'Command': {'DocumentName': 'string'}}
    ec2_client = boto3.client('ec2',region_name='us-east-1')
    s3_client = boto3.client('s3') 
    ssm_client = boto3.client('ssm',region_name='us-east-1') 
    ssm_id_VM = ['id1','id2']
    all_ssm_id = []
    instid = []
    temp_cred =  {
        
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)

        },
        'DocumentDescription': {
            'Name': 'string'
        },
        'PackedPolicySize': 123
    }
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    ssm_cli =  {
        
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)

        },
        'DocumentDescription': {
            'Name': 'string'
        },
        'PackedPolicySize': 123
    }

    file1.boto3.client('ssm').send_command(InstanceIds=['id1'],OutputS3BucketName='test_OutputS3BucketName',DocumentName='test_SSMAgentDocument').return_value = ssm_cmd
    with mock.patch('file1.open',mock.mock_open(),create=True) as mock_file3:
        response =  file1.processVMs(ssm_id_VM=['id1','id2'],all_ssm_id=['id3','id4'],SSMAgentDocument='test_SSMAgentDocument',outputFolderName='test_output',bucketName='test_bucketName',ssm_client=ssm_cli,accid=['id5','id6'],s3Client=s3_cli,region='us-east-1',master_credentials=temp_cred)
    assert response == 'success'

##################################################################################################
##############   Test Case for Execution GetmasterCredential                         #############                                                   
##################################################################################################
def test_getMasterRoleCredentials(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}

    stscli = boto3.client('sts',
                region_name = 'string' ,  
                aws_access_key_id = 'string',  
                aws_secret_access_key = 'string',  
    )
    file1.boto3.client('sts').getMasterRoleCredentials(access_key='test_accesskey',secret_access_key='test_SecretKey').return_value=stscli
    response = file1.getMasterRoleCredentials(access_key='test_accesskey',secret_access_key='test_SecretKey')

    assert response != 'credentials'

def test_getMasterRoleCredentials_cred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}

    stscli = boto3.client('sts',
                region_name = 'string' ,  
                aws_access_key_id = 'string',  
                aws_secret_access_key = 'string',  
    )
    file1.boto3.client('sts').getMasterRoleCredentials(access_key='test_accesskey',secret_access_key='test_SecretKey').return_value=stscli
    response = file1.getMasterRoleCredentials(access_key='test_accesskey',secret_access_key='test_SecretKey')

    assert response != ' '
##################################################################################################
##############   Test Case for Create SSM document files from template               #############                                                  
##################################################################################################
def test_createSSMFileFromTemplate(mocker):
    mocker.patch.object(file1, 'boto3')
    data1 = {}
    file1.createSSMFileFromTemplate(account_id=1223344)
    response = file1.createSSMFileFromTemplate(account_id=1223344)
    
    try:
        tm1 = Template(data1)
        tm1.stream(account_id=1223344).dump('TripwireLinuxInstall.json')
        print ('SSM document for Linux created')
    except: return 'error'
    assert response == ' '

def test_createSSMFileFromTemplate_File(mocker):
    mocker.patch.object(file1, 'boto3')
    data1 = {}
    file1.createSSMFileFromTemplate(account_id=1223344)
    response = file1.createSSMFileFromTemplate(account_id=1223344)
    
    try:
        tm1 = Template(data1)
        tm1.stream(account_id=1223344).dump('TripwireLinuxInstall.json')
        print ('SSM document for Linux created')
    except: return 'error'
    assert response != 'test_SSMDocument'

##################################################################################################
##############   Test Case for Create Tag file                                       #############                                                   
##################################################################################################
def test_createTagFile(mocker):
    mocker.patch.object(file1, 'boto3')
    #mocker.patch('file1.Template','dummyTmp')
    #data = {}
    response = file1.createTagFile(buisnessUnit='test_BusinessUnit',
                                   cloudEnvironment='test_CloudEnvironment',
                                   programInitiative='test_ProgramInitiative',
                                   subscriptionNumber='test_Subscriptiative')
    '''
    tm = Template(data)
    tm.stream(business_unit='test_BusinessUnit',
              cloud_environment='test_CloudEnvironment',
              subscription_number='test_Subscriptiative',
              program_initiative='test_ProgramInitiative').dump('metadata.yml')
    print ('Tag file created')'''
    assert response != " "

def test_createTagFile_Tag(mocker):
    mocker.patch.object(file1, 'boto3')
    #mocker.patch('file1.Template','dummyTmp')
    #data = {}
    
    response = file1.createTagFile(buisnessUnit='test_BusinessUnit',
                                   cloudEnvironment='test_CloudEnvironment',
                                   programInitiative='test_ProgramInitiative',
                                   subscriptionNumber='test_Subscriptiative')
    '''
    tm = Template(data)
    tm.stream(business_unit='test_BusinessUnit',
              cloud_environment='test_CloudEnvironment',
              subscription_number='test_Subscriptiative',
              program_initiative='test_ProgramInitiative').dump('metadata.yml')
    print ('Tag file created')'''
    assert response != "Test_Tag"
    

##################################################################################################
##############   Test Case for Upload tag and output files to S3 bucket              #############                                                   
##################################################################################################
def test_uploadFileToBucket(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').uploadFileToBucket(File_name='test_filename',
                                                Bucket = 'test_bucket',
                                                object_name=None).return_value = s3_cli 
    response = file1.uploadFileToBucket(file_name="test_filename",
                                       bucket="test_bucket",
                                       credentials=None)
    try:
        response = "test_filename"
        response = s3_client.upload_file( bucket="test_bucket", ExtraArgs={'ACL': 'public-read'}).return_value
        return response
    except: return "error"
    assert response.return_value['Bucket'] == "test_bucket"

def test_uploadFileToBucket_File(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').uploadFileToBucket(File_name='test_filename',
                                                Bucket = ' ',
                                                object_name=None).return_value = s3_cli 
    response = file1.uploadFileToBucket(file_name="test_filename",
                                       bucket="test_bucket",
                                       credentials=None)
    try:
        response = " "
        response = s3_client.upload_file( bucket=" ", ExtraArgs={'ACL': 'public-read'}).return_value
        return response
    except: return "error"
    assert response.return_value['Bucket'] == " "
##################################################################################################
##############   Test Case for Check if correct agent version there is in the bucket #############                                                   
##################################################################################################
def test_checkAgentVersion(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    #s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').checkAgentVersion(File_name='test_filename',
                                                Bucket = 'test_bucket',).return_value = s3_cli 
    response = file1.checkAgentVersion(fileName="test_filename",
                                       bucketName="test_bucket",
                                       credentials=None)
    assert response != "test_bucket"

def test_checkAgentVersion_Agent(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    #s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').checkAgentVersion(File_name='test_filename',
                                                Bucket = '',).return_value = s3_cli 
    response = file1.checkAgentVersion(fileName="test_filename",
                                       bucketName="test_bucket",
                                       credentials=None)
    assert response != " "
'''
import os
import mock
import pytest
import file1
import datetime
import boto3
import csv
from unittest.mock import Mock
import botocore.session
from jinja2 import Template
from botocore.stub import Stubber, ANY
 
##################################################################################################
##############                Test Case for Get Account Credentials                    ###########
##################################################################################################
def test_GetAccountCredentials(mocker):
    Credential = {
        'AccessKeyId': '12345678',
        'AccessScretKeyId': 'string',
        'Servicetoken': 'string'
    }
    Credential1 = {
        'AccessKeyId': '87654321',
        'AccessScretKeyId': 'string',
        'Servicetoken': 'string'
    }
    response = file1.GetAccountCredentials(AccountId='123456789',MasterRoleCredentials=Credential)      
    assert response == Credential

def test_GetAccountCredentials(mocker):
    Credential1 = {
        'AccessKeyId': '87654321',
        'AccessScretKeyId': 'string',
        'Servicetoken': 'string'
    }
    response = file1.GetAccountCredentials(AccountId='123456789',MasterRoleCredentials={})     
    assert response == 'InvalidCredentials'

##################################################################################################
##############                Test Case for Assume_Role                                ###########
##################################################################################################
def test_assume_role(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }

    response = file1.assume_role(role_arn="test_role_arn",
                                 session_name="test_session_name", credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    assert response.return_value["Credentials"] == {
        'AccessKeyId': 'string',
        'SecretAccessKey': 'string',
        'SessionToken': 'string',
        'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
    }
test_assume_role


def test_assume_role_cred_none(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }

    response = file1.assume_role(role_arn="test_role_arn",
                                 session_name="test_session_name", credentials=None)
    assert response.return_value["Credentials"] == {
        'AccessKeyId': 'string',
        'SecretAccessKey': 'string',
        'SessionToken': 'string',
        'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
    }
test_assume_role_cred_none

##################################################################################################
##############                Test Case for New_Sts_Func                               ###########
##################################################################################################
def test_NewStsFunc(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.NewStsFunc(AccountId="234567891",
                                RoleName="test_role_name")
    assert response != {'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
            }

def test_NewStsFuncCred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.NewStsFunc(AccountId="234567891",
                                 RoleName="test_role_name")
    assert response != {} 
##################################################################################################
##############                Test Case for Sts_Func1                                  ###########
##################################################################################################
def test_StsFunc1(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.StsFunc1(AccountId="234567891",
                                 RoleName="test_role_name",
                                 AccessKey="test",SecretKey="test",Token="test")
    assert response != {'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
            }

def test_StsFunc1Cred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}
    file1.boto3.client('sts').assume_role(RoleArn="test_role_arn",
                                          RoleSessionName='test_session_name',
                                          DurationSeconds=990).return_value = {
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)
        },
        'AssumedRoleUser': {
            'AssumedRoleId': 'string',
            'Arn': 'string'
        },
        'PackedPolicySize': 123
    }
    response = file1.StsFunc1(AccountId="234567891",
                                 RoleName="test_role_name",
                                 AccessKey="test",SecretKey="test",Token="test")
    assert response != {}

##################################################################################################
##############                Test Case for checkSSMDocument                           ###########
##################################################################################################
def test_checkSSMDocument(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'describe_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    #mocker.patch('file1.boto3.client',return_value= {})
    #mocker.patch ('describe_document', return_value = 'test_docname')
    file1.boto3.client('ssm').describe_document(DocName='test_docname').return_value = {'Document': {'Name':'test_docname'}}
    response = file1.checkSSMDocument(DocName='test_docname',Region='us-east-1',Credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})

    assert response.return_value['Document']['Name'] == 'test_docname'
test_checkSSMDocument


def test_checkSSMDocument_none(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'describe_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    #mocker.patch('file1.boto3.client',return_value= {})
    #mocker.patch ('describe_document', return_value = 'test_docname')
    file1.boto3.client('ssm').describe_document(DocName='test_docname').return_value = {'Document': {'Name':'test_docname'}}
    response = file1.checkSSMDocument(DocName='test_docname',Region='us-east-1',Credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})

    assert response.return_value['Document']['Name'] == 'test_docname'
test_checkSSMDocument_none
##################################################################################################
##############         Test Case for Create SSM document through API              ################                                                     
##################################################################################################

def test_createDocument1(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('ssm').return_value = {}
    file1.boto3.client('ssm').create_document(docName='test_docname',DocumentType='test_content').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    
    with mock.patch('file1.open',mock.mock_open(read_data="ssmDocumentFile"),create=True) as mock_file1:
        response =  file1.createDocument(docName='test_docname',region='us-east-2',localPath='test_path',credentials=None)
    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_createDocument1

def test_createDocument2(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('ssm').return_value = {}
    file1.boto3.client('ssm').create_document(docName='test_docname',DocumentType='test_content').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    
    with mock.patch('file1.open',mock.mock_open(read_data="ssmDocumentFile"),create=True) as mock_file1:
        response =  file1.createDocument(docName='test_docname',region='us-east-2',localPath='test_path',credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_createDocument2

##################################################################################################
##############         Test Case for Delate SSM document through API              ################                                                    
##################################################################################################
def test_DeleteDocument(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'create_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    file1.boto3.client('ssm').delete_document(DocName='test_docname').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    response = file1.DeleteDocument(DocName='test_docname',Region='us-east-2',Credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_DeleteDocument

def test_DeleteDocumentCred(mocker):
    mocker.patch.object(file1, 'boto3')
    ssm = {'create_document': 'test_docname'}
    file1.boto3.client('ssm').return_value = ssm
    file1.boto3.client('ssm').delete_document(DocName='test_docname').return_value = {'DocumentDescription': {'Name':'test_docname'}}
    response = file1.DeleteDocument(DocName='test_docname',Region='us-east-2',Credentials=None)

    assert response.return_value['DocumentDescription']['Name'] == 'test_docname'
test_DeleteDocumentCred

##################################################################################################
##############               Test Case for CreateOutputBucket                     ################                                                     
##################################################################################################

def test_CreateOutputBucket(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli =  {
        'Credential94' : {
            'AccessKeyId': '234567894',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
        },    
            'Location': 'string'  
    }
    file1.boto3.client('s3').CreateOutputBucket(AccountId="234567894",
                                            MasterRoleCredentials=s3_cli,
                                            DurationSeconds=990).return_value = s3_cli
                                             
    response = file1.CreateOutputBucket(AccountId="234567894",
                                        MasterRoleCredentials=None)
    try:
        response=s3_client.create_bucket(ACL='public-read-write', 
                                        Bucket='test_bucketName').return_value
    except Exception as e:
        print (e)
        return 'test_bucketName'
    
    assert response.return_value["Bucket"] == 'test_bucketName'

def test_CreateOutputBucketCred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli =  {
        'Credential94' : {
            'AccessKeyId': '234567894',
            'SecretAccessKey': 'string',
            'SessionToken': 'string'
        },    
            'Location': 'string'  
    }
    file1.boto3.client('s3').CreateOutputBucket(AccountId="234567894",
                                            MasterRoleCredentials=s3_cli,
                                            DurationSeconds=990).return_value = s3_cli
                                             
    response = file1.CreateOutputBucket(AccountId="234567894",
                                        MasterRoleCredentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    try:
        response=s3_client.create_bucket(ACL='public-read-write', 
                                        Bucket='test_bucketName').return_value
    except Exception as e:
        print (e)
        return ' '
    
    assert response.return_value["Bucket"] != 'test_bucketName'

##################################################################################################
##############   Test Case for Upload tag and output files to S3 bucket              #############                                                   
##################################################################################################
def test_UploadFileToBucket(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').UploadFileToBucket(FileName='test_filename',
                                                Bucket = 'test_bucket',
                                                ObjectName=None).return_value = s3_cli 
    response = file1.UploadFileToBucket(FileName="test_filename",
                                       Bucket="test_bucket",
                                       Credentials=None)
    try:
        response = "test_filename"
        response = s3_client.upload_file( bucket="test_bucket", ExtraArgs={'ACL': 'public-read'}).return_value
        return response
    except: return "error"
    assert response.return_value['Bucket'] == "test_bucket"

def test_UploadFileToBucketCred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').UploadFileToBucket(FileName='test_filename',
                                                Bucket = 'test_bucket',
                                                ObjectName=None).return_value = s3_cli 
    response = file1.UploadFileToBucket(FileName="test_filename",
                                       Bucket="test_bucket",
                                       Credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    try:
        response = "test_bucket"
        response = s3_client.upload_file( Bucket=" ", ExtraArgs={'ACL': 'public-read'}).return_value
        return response
    except: return "error"
    assert response.return_value['Bucket'] != "test_bucket"

##################################################################################################
##############   Test Case for CreateOutputBucketCheck if SSM document already there #############                                                   
##################################################################################################
def test_CreateSSMDocuments(mocker):
   # mocker.patch.object(file1, 'boto3')
    mocker.patch('file1.checkSSMDocument',return_value= 'dummydocname')
    mocker.patch('file1.createDocument',return_value='dummydoccreate')
    mocker.patch('file1.DeleteDocument',return_value='dummydocdeleted')
    mocker.patch('file1.CreateOutputBucket',return_value='dummycreateOutputBucket')
    response = file1.CreateSSMDocuments(SSMAgentDocument='test_SSMAgentDocument',
                            JsonDocument='test_jsondoc',
                            Region='us-east-1',
                            Credentials={},MasterRoleCredentials={},CurrentAccount=12345777)
    assert response == "dummycreateOutputBucket"

def test_CreateSSMDocumentsCred(mocker):
   # mocker.patch.object(file1, 'boto3')
    mocker.patch('file1.checkSSMDocument',return_value= 'dummydocname')
    mocker.patch('file1.createDocument',return_value='dummydoccreate')
    mocker.patch('file1.DeleteDocument',return_value='dummydocdeleted')
    mocker.patch('file1.CreateOutputBucket',return_value='dummycreateOutputBucket')
    response = file1.CreateSSMDocuments(SSMAgentDocument='test_SSMAgentDocument',
                            JsonDocument='test_jsondoc',
                            Region='us-east-1',
                            Credentials={},MasterRoleCredentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"},CurrentAccount=12345777)
    assert response != "dummycreateOutputBucket "

##################################################################################################
##############   Test Case for GetFileNameAsOutputVariable                           #############                                                   
##################################################################################################
def test_GetFileNameAsOutputVariable(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.GetFileNameAsOutputVariable(VMDetailsFile='test_VMfile',OutputFileName='test_Outputfilename')
    with mock.patch('os.listdir') as mocked_listdir:
        mocked_listdir = ['test_listfile']
    response = file1.GetFileNameAsOutputVariable(VMDetailsFile="test_VMfile",
                                                OutputFileName="test_Outputfilename")
    assert response == 'success'
test_GetFileNameAsOutputVariable


def test_GetFileNameAsOutputVariableFilename(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.GetFileNameAsOutputVariable(VMDetailsFile='test_VMfile',OutputFileName='')
    with mock.patch('os.listdir') as mocked_listdir:
        mocked_listdir = ['test_listfile']
    response = file1.GetFileNameAsOutputVariable(VMDetailsFile=None,
                                                OutputFileName=None)
    assert response == 'Failure'
test_GetFileNameAsOutputVariableFilename

##################################################################################################
##############   Test Case for Installing Tripwire agent on VMs                      #############                                                   
##################################################################################################

# Installing Tripwire agent on VMs
def test_InstallTripwire(mocker):
    mocker.patch.object(file1, 'boto3')
    mocker.patch.object(file1,'csv')
    ssm_client = boto3.client('ssm',region_name='us-east-1')
    
    #writer = csv.writer('filehandel')
    s3_client = boto3.client('s3')
    file1.boto3.client('ssm').describe_instance_information().return_value = {'InstanceInformationList':[{'InstanceId': 'string','PlatformType': 'Linux','Name': 'string','AgentVersion': 'string'},], 'NextToken': 'string'}
    unix = ['dummyUnixId']
    win = ['dummyWinId']
    temp_cred =  {
        
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)

        },
        'DocumentDescription': {
            'Name': 'string'
        },
        'PackedPolicySize': 123
    }
    mocker.patch('file1.GetAccountCredentials',return_value=temp_cred)
    mocker.patch('file1.getVMDetails',return_value=[unix,win])
    mocker.patch('file1.CheckAgentVersion',return_value=True)
    mocker.patch('file1.CreateSSMFileFromTemplate',return_value=True)
    mocker.patch('file1.CreateSSMDocuments',return_value='dummyssmbucket')
    mocker.patch('file1.CreateTagFile',return_value=True)
    mocker.patch('file1.UploadFileToBucket',return_value=True)
    mocker.patch('file1.processVMs',return_value=True)
    
    mocker.patch('file1.GetFileNameAsOutputVariable',return_value='success')
    #mock = Mock('file1.getFileNameAsOutputVariable',return_value='success')
    file1.InstallTripwire(AccountList=[1,2], RegionList=['us-east-1'],InstanceIds=['id1','id2'],MasterCredentials={})
    #mocker.assert_called_once()
    file1.GetFileNameAsOutputVariable.assert_called_once()

##################################################################################################
##############   Test Case for Getting VM details like OS type etc                   #############                                                   
##################################################################################################
def test_getVMDetails(mocker):
    mocker.patch.object(file1, 'boto3')
    #SSMIdUnix=[]
    #SSMIdWin=[]
    #all_ssm_id=[]
    #InstanceIds=[]

    resp = {
        'InstanceInformationList':[
        {
            'InstanceId': 'string',
            'PlatformName': 'string',
            'PlatformType': 'win',
            'Name': 'string'
        }
        ]
    }
    '''mocker.patch('file1.response',return_value= {})
    mocker.patch('file1.ssm_id_unix',return_value='dummydoccreate')
    mocker.patch('file1.SSMIdWin',return_value='dummydocdeleted')
    mocker.patch('file1.SSMIdWin',return_value='dummydocdeleted')
    mocker.patch('file1.InstanceIds',return_value='dummycreateOutputBucket')'''
    file1.getVMDetails(response=resp,SSMIdUnix=[123456],
                       SSMIdWin=[1223344],AllSSMId=[1234455],InstanceIds=[556677])
    response = file1.getVMDetails(response=resp,SSMIdUnix=[123456],
                                  SSMIdWin=[1223344],AllSSMId=[1234455],InstanceIds=[556677])
    assert response == 'win'

def test_getVMDetailsUnix(mocker):
    mocker.patch.object(file1, 'boto3')
    #SSMIdUnix=[]
    #SSMIdWin=[]
    #all_ssm_id=[]
    #InstanceIds=[]

    resp1 = {
        'InstanceInformationList':[
        {
            'InstanceId': 'string',
            'PlatformName': 'string',
            'PlatformType': 'unix',
            'Name': 'string'
        }
        ]
    }

    file1.getVMDetails(response=resp1,SSMIdUnix=[123456],
                       SSMIdWin=[1223344],AllSSMId=[1234455],InstanceIds=[556677])
    response = file1.getVMDetails(response=resp1,SSMIdUnix=[123456],
                                  SSMIdWin=[1223344],AllSSMId=[1234455],InstanceIds=[556677])
    assert response != 'unix'

##################################################################################################
##############   Test Case for ProcessVMs                                            #############                                                   
##################################################################################################
def test_processVMs(mocker):
    mocker.patch.object(file1, 'boto3')
    mocker.patch.object(file1,'csv')
    file1.boto3.client('ssm').return_value = {}
    file1.boto3.client('ec2').return_value = {}
    file1.boto3.client('s3').return_value = {}
    ssm_cmd = {'Command': {'DocumentName': 'string'}}
    ec2_client = boto3.client('ec2',region_name='us-east-1')
    s3_client = boto3.client('s3') 
    ssm_client = boto3.client('ssm',region_name='us-east-1') 
    SSMIdVM = ['id1','id2']
    AllSSMId = []
    instid = []
    temp_cred =  {
        
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)

        },
        'DocumentDescription': {
            'Name': 'string'
        },
        'PackedPolicySize': 123
    }
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    ssm_cli =  {
        
        'Credentials': {
            'AccessKeyId': 'string',
            'SecretAccessKey': 'string',
            'SessionToken': 'string',
            'Expiration': datetime.datetime(2016, 1, 20, 22, 9)

        },
        'DocumentDescription': {
            'Name': 'string'
        },
        'PackedPolicySize': 123
    }

    file1.boto3.client('ssm').send_command(InstanceIds=['id1'],OutputS3BucketName='test_OutputS3BucketName',DocumentName='test_SSMAgentDocument').return_value = ssm_cmd
    with mock.patch('file1.open',mock.mock_open(),create=True) as mock_file3:
        response =  file1.processVMs(SSMIdVM=['id1','id2'],AllSSMId=['id3','id4'],SSMAgentDocument='test_SSMAgentDocument',outputFolderName='test_output',bucketName='test_bucketName',ssm_client=ssm_cli,accid=['id5','id6'],s3Client=s3_cli,region='us-east-1',MasterCredentials=temp_cred)
    assert response == 'success'
##################################################################################################
##############   Test Case for Execution GetmasterCredential                         #############                                                   
##################################################################################################
def test_GetMasterRoleCredentials(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}

    stscli = boto3.client('sts',
                region_name = 'string' ,  
                aws_access_key_id = 'string',  
                aws_secret_access_key = 'string',  
    )
    file1.boto3.client('sts').GetMasterRoleCredentials(AccessKey='test_accesskey',SecretAccessKey='test_SecretKey').return_value=stscli
    response = file1.GetMasterRoleCredentials(AccessKey='test_accesskey',SecretAccessKey='test_SecretKey')

    assert response != 'credentials'

def test_getMasterRoleCredentials_cred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('sts').return_value = {}

    stscli = boto3.client('sts',
                region_name = 'string' ,  
                aws_access_key_id = 'string',  
                aws_secret_access_key = 'string',  
    )
    file1.boto3.client('sts').GetMasterRoleCredentials(AccessKey='test_accesskey',SecretAccessKey='test_SecretKey').return_value=stscli
    response = file1.GetMasterRoleCredentials(AccessKey='test_accesskey',SecretAccessKey='test_SecretKey')

    assert response == 'success'
##################################################################################################
##############   Test Case for Create SSM document files from template               #############                                                  
##################################################################################################
def test_CreateSSMFileFromTemplate(mocker):
    mocker.patch.object(file1, 'boto3')
    data1 = {}
    file1.CreateSSMFileFromTemplate(AccountId=1223344)
    response = file1.CreateSSMFileFromTemplate(AccountId=1223344)
    
    try:
        tm1 = Template(data1)
        tm1.stream(AccountId=1223344).dump('TripwireLinuxInstall.json')
        print ('SSM document for Linux created')
    except: return 'error'
    assert response == 'Success '

def test_CreateSSMFileFromTemplateFile(mocker):
    mocker.patch.object(file1, 'boto3')
    data1 = {}
    file1.CreateSSMFileFromTemplate(AccountId=1223344)
    response = file1.CreateSSMFileFromTemplate(AccountId=1223344)
    
    try:
        tm1 = Template(data1)
        tm1.stream(AccountId=1223344).dump('TripwireWindowsInstall.json')
        print ('SSM document for Windows created')
    except: return 'error'
    assert response != 'Success'

##################################################################################################
##############   Test Case for Create Tag file                                       #############                                                   
##################################################################################################
def test_CreateTagFile(mocker):
    mocker.patch.object(file1, 'boto3')
    #mocker.patch('file1.Template','dummyTmp')
    #data = {}
    response = file1.CreateTagFile(buisnessUnit='test_BusinessUnit',
                                   cloudEnvironment='test_CloudEnvironment',
                                   programInitiative='test_ProgramInitiative',
                                   subscriptionNumber='test_Subscriptiative')
    '''
    tm = Template(data)
    tm.stream(business_unit='test_BusinessUnit',
              cloud_environment='test_CloudEnvironment',
              subscription_number='test_Subscriptiative',
              program_initiative='test_ProgramInitiative').dump('metadata.yml')
    print ('Tag file created')'''
    assert response != "Success "

def test_CreateTagFileTag(mocker):
    mocker.patch.object(file1, 'boto3')
    #mocker.patch('file1.Template','dummyTmp')
    #data = {}
    
    response = file1.CreateTagFile(buisnessUnit='test_BusinessUnit',
                                   cloudEnvironment='test_CloudEnvironment',
                                   programInitiative='test_ProgramInitiative',
                                   subscriptionNumber='test_Subscriptiative')
    '''
    tm = Template(data)
    tm.stream(business_unit='test_BusinessUnit',
              cloud_environment='test_CloudEnvironment',
              subscription_number='test_Subscriptiative',
              program_initiative='test_ProgramInitiative').dump('metadata.yml')
    print ('Tag file created')'''
    assert response == "Success"
##################################################################################################
##############   Test Case for Check if correct agent version there is in the bucket #############                                                   
##################################################################################################
def test_CheckAgentVersion(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    #s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').CheckAgentVersion(FileName='test_filename',
                                                Bucket = 'test_bucket',).return_value = s3_cli 
    response = file1.CheckAgentVersion(FileName="test_filename",
                                       BucketName="test_bucket",
                                       Credentials={"AccessKeyId": "test", "SecretAccessKey": "test", "SessionToken": "test"})
    assert response != "test_bucket"

def test_CheckAgentVersionCred(mocker):
    mocker.patch.object(file1, 'boto3')
    file1.boto3.client('s3').return_value = {}
    #s3_client = boto3.client('s3')
    s3_cli = {
        'credential':{
            'AccessKeyId':'string',
            'SecretAccessKey':'string',
            'SessionToken': 'string'
        }
    }
    file1.boto3.client('s3').CheckAgentVersion(FileName='test_filename',
                                                Bucket = 'test_bucket',).return_value = s3_cli 
    response = file1.CheckAgentVersion(FileName="test_filename",
                                       BucketName="test_bucket",
                                       Credentials=None)
    assert response != "test_bucket"
